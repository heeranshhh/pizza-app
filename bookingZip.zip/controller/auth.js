import User from "../models/User.js";

export const register = async (req,res,next) => {
    const newuser = new User({ 
        //could have done User(res.body), but later the password is going to be encoded for safety. that's why this way
        username: req.body.username,
        email: req.body.email,
        password: req.body.password
        //not writing isAdmin because default set to false    
    });
    try{
        await newuser.save();
        res.status(200).send('user has been created'); //201: status code for created successfully but doesn't matter much
    }catch(err){
        next(err);
    }
}