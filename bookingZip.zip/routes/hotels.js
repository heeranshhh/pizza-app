import express from 'express'
import { createHotel, deleteHotel, getHotelByID, updateHotel, getHotels } from '../controller/hotels.js';
const router = express.Router();

//CREATE, below methods in controller
router.post('/', createHotel);

//UPDATE
router.put('/:id',  updateHotel);

//DELETE
router.delete('/:id',  deleteHotel);

//GET a  specific hotel
router.get('/:id',  getHotelByID)

//GET ALL HOTELS
router.get('/',  getHotels);

export default router;